package com.moviesBooking.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class LoginRequest 
{
	@Email
	@NotBlank
   private String email;
   private String password;
}
